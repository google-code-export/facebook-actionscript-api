<?

//print_r($_POST);
//$sessionKey = $_POST['fb_sig_session_key'];

?>

<fb:add-section-button section="profile"/>
<hr />
<!-- 
Absolute URL to the SWF on your server. 

-->
<fb:swf id='facebookApp'
		swfsrc='webCamUploader.swf'
		imgsrc='webcampreview.jpg'
		swfbgcolor='006599'
		width='214' 
		height='255' /> 


